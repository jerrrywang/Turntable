import React, {Component} from 'react';

export class Stats extends Component {
  // constructor(props){
  //   super(props);
  //
  // }



// LoyaltyRate (dropdown with contributing factors)
// currentpoints
// totalpoints
// djElo
// current badge

  render(){
    return (<div styles={{border: '1px solid black'}}>
      STATS
    </div>)
  }
}
